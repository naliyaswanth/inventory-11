package com.ims.daoImplementations;

import com.ims.bean.ItemBean;
import com.ims.bean.VendorBean;
import com.ims.daointerfaces.ItemDao;
import com.ims.utilty.DBUtility;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ItemDaoImplementation implements ItemDao{

		@Override
	public void addItem(ItemBean item)
			throws ClassNotFoundException, SQLException {
		
		Connection con = DBUtility.getConnection();
		
		Statement st=con.createStatement();
		if(st==null){
			System.out.println("Not Connected");
		}
		else{
			System.out.println("Connected");
		}
		
        PreparedStatement psmt;
        psmt = con.prepareStatement("insert into ItemDetails values(?,?,?,?,?,?,?)");
                 
         psmt.setString(1, item.getItemID());
         psmt.setString(2, item.getItemName());
         psmt.setString(3, item.getItemType());
         psmt.setString(4, item.getQuantity());
         psmt.setString(5, item.getPrice());
         psmt.setString(6, item.getVendorID());
         psmt.setString(7, item.getWarehouseID());
         
         
         //System.out.println("Vendor Added Successfully"); 
         
         psmt.executeUpdate();
        // DBUtility.closeConnection(con);
         
         
	}

		
	public void modifyItem(String itemID,ItemBean item) throws ClassNotFoundException,SQLException {
            Connection con = DBUtility.getConnection();
		 PreparedStatement psmt = con.prepareStatement("update ItemDetails set itemname=?,itemtype=?,quantity=?,price=?,vendorid=?,warehouseid=? where itemid=?");
		psmt.setString(7, item.getItemID());
         psmt.setString(1, item.getItemName());
         psmt.setString(2, item.getItemType());
         psmt.setString(3, item.getQuantity());
         psmt.setString(4, item.getPrice());
         psmt.setString(5, item.getVendorID());
         psmt.setString(6, item.getWarehouseID());
		 
		 //
                 System.out.println("Record modified Successfully");
	psmt.executeUpdate();	 
         //DBUtility.closeConnection(con); 	
	}

	@Override
	public void deleteItem(ItemBean item) throws ClassNotFoundException,SQLException {
		
		 Connection con = DBUtility.getConnection();
		 PreparedStatement psmt = con.prepareStatement("delete from ItemDetails where itemid=?	");
		 psmt.setString(1, item.getItemID());
		 
		 System.out.println("Record Deleted Successfully");
		 
		 psmt.executeUpdate();
        // DBUtility.closeConnection(con);		 
	}

	@Override
	public ResultSet viewItem() throws ClassNotFoundException,SQLException {
		
		 Connection con = DBUtility.getConnection();
		 Statement st=con.createStatement();
		 //PreparedStatement psmt = con.prepareStatement("select * from itemdetails");
				 				 
		 /*psmt.executeQuery("select * from itemdetails");	*/	 
		 ResultSet rs=st.executeQuery("select * from ItemDetails order by itemname ");		 
		 	 		 		 
		 /*while(rs.next()){
		 System.out.println("Item ID: "+rs.getString("itemid"));
		 System.out.println("Item Name: "+rs.getString("itemname"));
		 System.out.println("Item Type: "+rs.getString("itemtype"));
		 System.out.println("Item Quantity: "+rs.getString("quantity"));
		 System.out.println("Item Price: "+rs.getString("price"));		
		 System.out.println(" \n");
		 }*/
               //  DBUtility.closeConnection(con); 
	
		return rs;		
	
	}

    @Override
	public ResultSet searchItem(ItemBean item) throws ClassNotFoundException,SQLException {
		
		Connection con = DBUtility.getConnection();
		
		 PreparedStatement psmt = con.prepareStatement("select * from itemdetails where itemid=?");	
		psmt.setString(1, item.getItemID());
		ResultSet rs= psmt.executeQuery();
      // DBUtility.closeConnection(con);
		return rs;		
	}
    /**
     *
     * @param item
     * @return
     * @throws ClassNotFoundException
     * @throws SQLException
     */
  /*  @Override
	public ResultSet searchItemW(ItemBean item) throws ClassNotFoundException,SQLException
	{
		Connection con = DBUtility.getConnection();
		
		 PreparedStatement psmt = con.prepareStatement("select * from itemdetails where warehouseid=?");	
			psmt.setString(1, item.getWarehouseID());
			ResultSet rs= psmt.executeQuery();
		
			while(rs.next()){
			 System.out.println("Item ID: "+rs.getString("itemid"));
			 System.out.println("Item Name: "+rs.getString("itemname"));
			 System.out.println("Item Type: "+rs.getString("itemtype"));
			 System.out.println("Item Quantity: "+rs.getString("quantity"));
			 System.out.println("Item Price: "+rs.getString("price"));		
			 System.out.println(" \n");
			 }
			return rs;
	}*/
    @Override
		public ResultSet filterItemA() throws ClassNotFoundException,SQLException
	{
	Connection con = DBUtility.getConnection();
		 Statement st=con.createStatement();
		 //PreparedStatement psmt = con.prepareStatement("select * from itemdetails");
				 				 
		 /*psmt.executeQuery("select * from itemdetails");	*/	 
		 ResultSet rs=st.executeQuery("select * from ItemDetails where itemtype='Tablet'");
                 System.out.println("Something");
			/*while(rs.next()){
			 System.out.println("Item ID: "+rs.getString("itemid"));
			 System.out.println("Item Name: "+rs.getString("itemname"));
			 System.out.println("Item Type: "+rs.getString("itemtype"));
			 System.out.println("Item Quantity: "+rs.getString("quantity"));
			 System.out.println("Item Price: "+rs.getString("price"));		
			 System.out.println(" \n");
			 }*/
                      //  DBUtility.closeConnection(con); 
	
			return rs;
	}
    @Override
        public ResultSet filterItemB() throws ClassNotFoundException,SQLException
        {
           Connection con = DBUtility.getConnection();
		 Statement st=con.createStatement();
		 //PreparedStatement psmt = con.prepareStatement("select * from itemdetails");
				 				 
		 /*psmt.executeQuery("select * from itemdetails");	*/	 
		 ResultSet rs=st.executeQuery("select * from ItemDetails where itemtype='Capsule'");
                 System.out.println("In capsule");
			/*while(rs.next()){
			 System.out.println("Item ID: "+rs.getString("itemid"));
			 System.out.println("Item Name: "+rs.getString("itemname"));
			 System.out.println("Item Type: "+rs.getString("itemtype"));
			 System.out.println("Item Quantity: "+rs.getString("quantity"));
			 System.out.println("Item Price: "+rs.getString("price"));		
			 System.out.println(" \n");
			 }*/
                      //  DBUtility.closeConnection(con); 
	
			return rs;
        }
        
    @Override
    public ResultSet filterItemC() throws ClassNotFoundException,SQLException
        {
            Connection con = DBUtility.getConnection();
		 Statement st=con.createStatement();
		 //PreparedStatement psmt = con.prepareStatement("select * from itemdetails");
				 				 
		 /*psmt.executeQuery("select * from itemdetails");	*/	 
		 ResultSet rs=st.executeQuery("select * from ItemDetails where itemtype='Injection'");
                 System.out.println("Something");
			/*while(rs.next()){
			 System.out.println("Item ID: "+rs.getString("itemid"));
			 System.out.println("Item Name: "+rs.getString("itemname"));
			 System.out.println("Item Type: "+rs.getString("itemtype"));
			 System.out.println("Item Quantity: "+rs.getString("quantity"));
			 System.out.println("Item Price: "+rs.getString("price"));		
			 System.out.println(" \n");
			 }*/
                      //  DBUtility.closeConnection(con); 
	
			return rs;
	}
        
}