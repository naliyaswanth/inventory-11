package com.ims.daoImplementations;

import com.ims.bean.VendorBean;
import com.ims.bean.WarehouseBean;
import com.ims.daointerfaces.WarehouseDao;
import com.ims.utilty.DBUtility;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class WarehouseDaoImplementation implements WarehouseDao {

	@Override
	public void addWarehouse(WarehouseBean warehouse)
			throws ClassNotFoundException, SQLException {
		
		Connection con = DBUtility.getConnection();
		
		Statement st=con.createStatement();
		if(st==null){
			System.out.println("Not Connected");
		}
		else{
			System.out.println("Connected");
		}
		
        PreparedStatement psmt = con.prepareStatement("insert into WarehouseDetails values(?,?,?,?)");
                 
         psmt.setString(1, warehouse.getWarehouseID());
         psmt.setString(2, warehouse.getWarehouseName());
         psmt.setString(3, warehouse.getWarehouseCapacity());
         psmt.setString(4, warehouse.getWarehouseAddress());
         
         System.out.println("Warehouse Added Successfully"); 
         
         psmt.executeUpdate();
         DBUtility.closeConnection(con);
         
         
	}

	
    @Override
	public void modifyWarehouse(String WarehouseID,WarehouseBean warehouse) throws ClassNotFoundException,SQLException {
            Connection con = DBUtility.getConnection();
		 PreparedStatement psmt = con.prepareStatement("update WarehouseDetails set warehousename=?,warehousecapacity=?,warehouseaddress=? where warehouseid=?");
		psmt.setString(4, warehouse.getWarehouseID());
                psmt.setString(1, warehouse.getWarehouseName());
                psmt.setString(2, warehouse.getWarehouseCapacity());
                psmt.setString(3, warehouse.getWarehouseAddress());
		 
		 //
                 System.out.println("Record modified Successfully");
	psmt.executeUpdate();	 
         DBUtility.closeConnection(con);
    }

	@Override
	public void deleteWarehouse(WarehouseBean warehouse) throws ClassNotFoundException, SQLException {
		
		Connection con = DBUtility.getConnection();
		 PreparedStatement psmt = con.prepareStatement("delete from warehouseDetails where warehouseid=?	");
		 //psmt.setString(1, warehouse.getwarehouseID());
		 psmt.setString(1, warehouse.getWarehouseID());
		 System.out.println("Record Deleted Successfully");
		 
		 psmt.executeUpdate();
        DBUtility.closeConnection(con);	
	}

    /**
     *
     * @return
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    @Override
	public ResultSet viewWarehouse() throws ClassNotFoundException, SQLException {
		
		 Connection con = DBUtility.getConnection();
		 Statement st=con.createStatement();
		 
		 ResultSet rs=st.executeQuery("select * from WarehouseDetails");		 
		 	 		 		 
	
		return rs;		
	}

	@Override
	public ResultSet searchWarehouse(WarehouseBean warehouse) throws ClassNotFoundException, SQLException {
		Connection con = DBUtility.getConnection();
		System.out.println("search inside");
		PreparedStatement preparedStatement=con.prepareStatement("select * from warehousedetails where warehouseid=?");
		preparedStatement.setString(1, warehouse.getWarehouseID());
		ResultSet set=preparedStatement.executeQuery();
		System.out.println("search outside");
	return set;
	}

}
