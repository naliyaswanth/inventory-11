package com.ims.daofactory;

import com.ims.daoImplementations.ItemDaoImplementation;
import com.ims.daoImplementations.LoginDaoImplementation;
import com.ims.daoImplementations.VendorDaoImplementation;
import com.ims.daoImplementations.WarehouseDaoImplementation;
import com.ims.daointerfaces.ItemDao;
import com.ims.daointerfaces.LoginDao;
import com.ims.daointerfaces.VendorDao;
import com.ims.daointerfaces.WarehouseDao;

public class DaoFactory {

	private static LoginDao loginDao=null;
	private static ItemDao itemDao= null;
	private static VendorDao vendorDao= null;
	private static WarehouseDao warehouseDao= null;
	
	//Getting LoginDao
	public static LoginDao getLoginDao(){
		if(loginDao==null){
			loginDao=new LoginDaoImplementation();			
		}
		else{
			return loginDao;			
		}
		return loginDao;
	}
	
	//Getting ItemDao
	public static ItemDao getItemDao() {
		if(itemDao==null){
			itemDao=new ItemDaoImplementation();
		}else{
			return itemDao;
		}
		return itemDao;
	}	
	
	//Getting VendorDao
	public static VendorDao getVendorDao() {
		if(vendorDao==null){
			vendorDao=new VendorDaoImplementation();
		}else{
			return vendorDao;
		}
		return vendorDao;
	}	
	
	//Getting WarehouseDao
	public static WarehouseDao getWarehouseDao() {
		if(warehouseDao==null){
			warehouseDao=new WarehouseDaoImplementation();
		}else{
			return warehouseDao;
		}
		return warehouseDao;
	}	
}
