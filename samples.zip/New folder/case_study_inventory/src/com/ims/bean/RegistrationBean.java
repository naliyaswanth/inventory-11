/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ims.bean;

/**
 *
 * @author techm
 */
public class RegistrationBean {
   
	
	private String userName;
        private String password;
	private String dateOfBirth;
        private String emailId;
        private String contactNumber;
	private String address;
        private String postCode;
	
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
        public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
        }
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	
	public void setAddress(String address){
		
		this.address=address;
	}
	public String getAddress(){
		
		return address;
		
	}
        public void setPostcode(String postCode){
		
		this.postCode=postCode;
	}
	public String getPostCode(){
		
		return postCode;
		
	}
	
	
	
    
}
    
