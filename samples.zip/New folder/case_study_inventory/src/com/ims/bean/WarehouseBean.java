package com.ims.bean;

public class WarehouseBean {

	private String warehouseID;
	private String warehouseName;	
	private String warehouseCapacity;	
	private String warehouseAddress;
	
        //define constructor
        
	public String getWarehouseID() {
		return warehouseID;
	}
	public void setWarehouseID(String warehouseID) {
		this.warehouseID = warehouseID;
	}
	public String getWarehouseName() {
		return warehouseName;
	}
	public void setWarehouseName(String warehouseName) {
		this.warehouseName = warehouseName;
	}
	public String getWarehouseCapacity() {
		return warehouseCapacity;
	}
	public void setWarehouseCapacity(String warehouseCapacity) {
		this.warehouseCapacity = warehouseCapacity;
	}
	public String getWarehouseAddress() {
		return warehouseAddress;
	}
	public void setWarehouseAddress(String warehouseAddress) {
		this.warehouseAddress = warehouseAddress;
	}
	
}
