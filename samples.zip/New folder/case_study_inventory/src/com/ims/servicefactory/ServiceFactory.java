package com.ims.servicefactory;

import com.ims.services.ItemService;
import com.ims.services.LoginService;
import com.ims.services.VendorService;
import com.ims.services.WarehouseService;
import com.ims.services.RegistrationService;

public class ServiceFactory {

	private static LoginService loginService=null;
	private static ItemService itemService=null;
	private static VendorService vendorService=null;
	private static WarehouseService warehouseService=null;
        private static RegistrationService registrationService=null;
	
	public static LoginService getLoginService(){
		if(loginService==null){
			loginService=new LoginService();
		}
		else{
			return loginService;
		}
		return loginService;
	}
	
	public static ItemService getItemService(){
		if(itemService==null){
			itemService=new ItemService();
		}
		else{
			return itemService;
		}
		return itemService;
	}
	
	public static VendorService getVendorService(){
		if(vendorService==null){
			vendorService=new VendorService();
		}
		else{
			return vendorService;
		}
		return vendorService;
	}
	public static WarehouseService getWarehouseService(){
		if(warehouseService==null){
			warehouseService=new WarehouseService();
		}
		else{
			return warehouseService;
		}
		return warehouseService;
	}
        public static RegistrationService getRegistrationService(){
		if(registrationService==null){
			registrationService=new RegistrationService();
		}
		else{
			return registrationService;
		}
		return registrationService;
	}
}
