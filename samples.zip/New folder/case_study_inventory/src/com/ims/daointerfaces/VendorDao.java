package com.ims.daointerfaces;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.ims.bean.VendorBean;

public interface VendorDao 
{
	public abstract void addVendor(VendorBean vendor) throws ClassNotFoundException, SQLException;
	public abstract void modifyVendor(String VendorID, VendorBean vendor)throws ClassNotFoundException, SQLException;
	public abstract void deleteVendor(VendorBean vendor)throws ClassNotFoundException, SQLException;
	public abstract ResultSet viewVendor()throws ClassNotFoundException, SQLException;
	public abstract ResultSet searchVendor(VendorBean vendor)throws ClassNotFoundException, SQLException;
}
