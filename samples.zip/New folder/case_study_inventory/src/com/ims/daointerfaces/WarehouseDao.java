package com.ims.daointerfaces;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.ims.bean.WarehouseBean;

public interface WarehouseDao
{
	public abstract void addWarehouse(WarehouseBean warehouse) throws ClassNotFoundException, SQLException;
	public abstract void modifyWarehouse(String warehouseID, WarehouseBean warehouse)throws ClassNotFoundException, SQLException;
	public abstract void deleteWarehouse(WarehouseBean warehouse)throws ClassNotFoundException, SQLException;
	public abstract ResultSet viewWarehouse()throws ClassNotFoundException, SQLException;
	public abstract ResultSet searchWarehouse(WarehouseBean warehouse)throws ClassNotFoundException, SQLException;
	
}
