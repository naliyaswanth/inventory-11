package com.ims.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ims.bean.LoginBean;
import com.ims.servicefactory.ServiceFactory;
import com.ims.services.LoginService;

public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException{
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try 
        {
        	//getting the values from loginhtml form
             String userName = request.getParameter("userName");
             String passWord = request.getParameter("passWord");
             String role = "";
             
             System.out.println("UserName is:" +userName);
        	 System.out.println("Password is:" +passWord);
            
        	 //setting the values into the bean
	   		LoginBean login = new LoginBean();
        	login.setUserName(userName);
        	login.setPassWord(passWord);		
        	
        	LoginService loginService = ServiceFactory.getLoginService();
        	        	
        	try
        	{
        		//validating the user
        		System.out.println("validating the user");
         		role = loginService.validateUser(login);
        	}
        	catch(ClassNotFoundException ce)
        	{
        		ce.printStackTrace();
           
        	}
        	catch(SQLException se)
        	{
        		se.printStackTrace();
            
        	}
        	
        	//if the role is admin
        	if(role.equalsIgnoreCase("admin"))
        	{
        		HttpSession session=request.getSession();
        		session.setAttribute("userName",userName);
        		out.println("Welcome Admin");
        		/*String adminPage=getServletContext().getInitParameter("AdminHomePage");*/
        		RequestDispatcher rd = request.getRequestDispatcher("AdminHomePage.html");
        		rd.forward(request, response);        		
        	}

        	//if the role is user
        	if(role.equalsIgnoreCase("user"))
        	{
        		HttpSession session = request.getSession();
        		session.setAttribute("userName",userName);
        		/*String userPage = getServletContext().getInitParameter("UserHomePage");*/
        		System.out.println("finally back");
        		RequestDispatcher rd = request.getRequestDispatcher("UserHomePage.jsp");
        		rd.forward(request, response);
        		System.out.println("finally back");
        	}
        	
        	//if the entered user is not registered
        	if(role.equalsIgnoreCase("invalid"))
        	{
        		System.out.println("invalid user");
        		/*String invalidPage = getServletContext().getInitParameter("InvalidPage");*/
        		RequestDispatcher rd = request.getRequestDispatcher("InvalidPage.jsp");
        		rd.forward(request, response);
        	}        	
        	
        }
        finally
        { 
            out.close();
        }

	}
}
